Shift: Start Timer
Tab: Stop Timer
Backspace: Toggle Perfect Clears

Plus: Add Minute from Timer
Minus: Subtract Minute from Timer

Ctrl + Backspace: Clear Log
Ctrl + Enter: Toggle Log Visibility